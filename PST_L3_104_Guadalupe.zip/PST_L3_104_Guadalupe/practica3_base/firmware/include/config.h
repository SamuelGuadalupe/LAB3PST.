#pragma once
// Copia este archivo como config.h. No publiques config.h.
const char* WIFI_SSID = "Lab. Telematica";
const char* WIFI_PASSWORD = "l4bt3l3m4tic@";
// IPv4 de la computadora que ejecuta FastAPI; no uses localhost.
const char* API_URL = "http://192.168.100.150:8000/lecturas";
const char* DISPOSITIVO = "equipo01";
